<?php
if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}exit();

?>